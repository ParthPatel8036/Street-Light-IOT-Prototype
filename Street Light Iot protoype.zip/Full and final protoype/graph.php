<?php
$xml = simplexml_load_file("log.xml");
$dataPoints1 = $dataPoints2 = [];

foreach ($xml->entry as $e) {
    $dataPoints1[] = ["label" => (string)$e->deviceTime, "y" => floatval($e->light)];
    $dataPoints2[] = ["label" => (string)$e->deviceTime, "y" => floatval($e->power)];
}
?>
<!DOCTYPE html>
<html>
<head>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer", {
        title: { text: "Light and Power Levels" },
        axisY: { title: "Sensor Values" },
        data: [
            {
                type: "line",
                name: "Light",
                showInLegend: true,
                dataPoints: <?= json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
            },
            {
                type: "line",
                name: "Power",
                showInLegend: true,
                dataPoints: <?= json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
            }
        ]
    });
    chart.render();
    setInterval(() => location.reload(), 5000);
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 400px; width: 100%;"></div>
</body>
</html>
