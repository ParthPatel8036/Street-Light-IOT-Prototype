from sense_emu import SenseHat
import time
import urllib.request
import json
from datetime import datetime

sense = SenseHat()
sense.clear()

# —— Configuration —— 
LIGHT_THRESHOLD  = 60      # light-on/off threshold (% humidity)
ANGLE_THRESHOLD  = 20.0    # degrees change → collision
REPORT_INTERVAL  = 60      # seconds between periodic sends
# ——————————————————————

# State
collision_detected = False
setup_mode         = False
power_state        = "normal"   # "normal", "brownout", or "surge"
last_yaw = last_pitch = last_roll = 0.0
last_report = time.time()

def send_data(light, power, collision):
    """POST JSON to the server; print ACK on success or error."""
    url = "http://iotserver.com/log_data.php"
    payload = {
        "light":     round(light,1),
        "power":     round(power,1),
        "collision": 1 if collision else 0,
        "threshold": LIGHT_THRESHOLD,
        "timestamp": datetime.now().isoformat()
    }
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type":"application/json"})
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        _ = resp.read()
        print("ACK")
    except Exception as e:
        print("‼️ Error posting data:", e)

def flash_leds():
    for _ in range(3):
        sense.clear(255,0,0)
        time.sleep(0.2)
        sense.clear()
        time.sleep(0.2)

def enter_setup_mode():
    """Adjust the light threshold via joystick, then send new threshold."""
    global LIGHT_THRESHOLD, setup_mode
    sense.show_message(f"Setup:{LIGHT_THRESHOLD}")
    start = time.time()
    while time.time() - start < 10:
        for evt in sense.stick.get_events():
            if evt.action != "pressed":
                continue
            start = time.time()
            if evt.direction == "up":
                LIGHT_THRESHOLD += 5
                sense.show_message(str(LIGHT_THRESHOLD))
            elif evt.direction == "down":
                LIGHT_THRESHOLD = max(0, LIGHT_THRESHOLD - 5)
                sense.show_message(str(LIGHT_THRESHOLD))
            elif evt.direction == "middle":
                sense.show_message("Done")
                setup_mode = False
                send_data(sense.get_humidity(), sense.get_temperature(), False)
                return
    sense.show_message("Done")
    setup_mode = False
    send_data(sense.get_humidity(), sense.get_temperature(), False)

# —— Initial connectivity test ——
send_data(0, 0, False)
# ————————————————————————

while True:
    # 1) Joystick: clear collision or enter setup
    for evt in sense.stick.get_events():
        if evt.action == "pressed" and evt.direction == "middle":
            if collision_detected:
                collision_detected = False
                sense.clear()
            else:
                setup_mode = True
                enter_setup_mode()
            break

    if setup_mode:
        time.sleep(0.1)
        continue

    # 2) Read orientation for collision detection
    ori   = sense.get_orientation_degrees()
    yaw   = ori['yaw']; pitch = ori['pitch']; roll = ori['roll']

    if (not collision_detected) and (
        abs(yaw   - last_yaw)   > ANGLE_THRESHOLD or
        abs(pitch - last_pitch) > ANGLE_THRESHOLD or
        abs(roll  - last_roll)  > ANGLE_THRESHOLD
    ):
        collision_detected = True
        print(f"⚠️ Collision detected at {datetime.now().isoformat()}")
        flash_leds()
        send_data(sense.get_humidity(),
                  sense.get_temperature(),
                  True)

    last_yaw, last_pitch, last_roll = yaw, pitch, roll

    # 3) Read humidity & temperature
    hum  = sense.get_humidity()
    temp = sense.get_temperature()

    # 4) Power override: brownout or surge
    if temp < 0:
        if power_state != "brownout":
            power_state = "brownout"
            print(f"⚡ Brownout detected ({temp:.1f}°C)")
        sense.clear()  # force LEDs OFF
    elif temp > 100:
        if power_state != "surge":
            power_state = "surge"
            print(f"⚡ Power surge detected ({temp:.1f}°C)")
        sense.clear()
    else:
        # back to normal power
        power_state = "normal"
        # 5) Streetlight on/off (only if not in collision)
        if not collision_detected:
            if hum < LIGHT_THRESHOLD:
                sense.clear(255,255,255)  # LEDs ON
            else:
                sense.clear()             # LEDs OFF

    # 6) Periodic report every REPORT_INTERVAL seconds
    now = time.time()
    if now - last_report >= REPORT_INTERVAL:
        send_data(hum, temp, collision_detected)
        last_report = now

    time.sleep(0.5)
