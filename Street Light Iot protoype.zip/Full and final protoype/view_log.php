<?php
// view_log.php

$xmlFile = __DIR__ . '/log.xml';

// 1) Handle the Reset button
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    // Wipe it back to an empty entries root
    file_put_contents(__DIR__ . '/log.xml', '<?xml version="1.0"?><entries></entries>');
    // Redirect to avoid “resubmit on refresh”
    header('Location: view_log.php');
    exit;
}

// 2) Load the XML
$xml = simplexml_load_file($xmlFile);

// 3) Compute summary & prepare table + chart data
$totalEntries   = count($xml->entry);
$abnormalPower  = 0;
$latestThreshold = 0;
$eventRows      = '';
$chartData      = [];

foreach ($xml->entry as $e) {
    $dt        = (string)$e->deviceTime;
    $light     = floatval($e->light);
    $power     = floatval($e->power);
    $collision = intval($e->collision);
    $threshold = intval($e->threshold);

    // Most recent threshold
    if ($threshold > 0) {
        $latestThreshold = $threshold;
    }
    // Count power faults
    if ($power < 0 || $power > 100) {
        $abnormalPower++;
    }
    // Build events table
    if ($collision === 1 || $power < 0 || $power > 100) {
        if ($collision === 1) {
            $label = "Collision";
        } elseif ($power < 0) {
            $label = "Brownout";
        } else {
            $label = "Power Surge";
        }

        $eventRows .= "<tr>
            <td>{$dt}</td>
            <td>{$power}</td>
            <td>{$label}</td>
        </tr>\n";
    }

    // Collect for chart
    $chartData[] = [
      'deviceTime' => $dt,
      'light'      => $light,
      'power'      => $power
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Streetlight Log</title>
  <script src="canvasjs3.6/canvasjs.min.js"></script>
  <style>
    body { font-family: sans-serif; padding: 1em; }
    table { border-collapse: collapse; width: 100%; margin-bottom: 2em; }
    th, td { border: 1px solid #666; padding: 0.5em; }
    th { background: #eee; }
    .reset-btn { margin-bottom: 1em; }
  </style>
</head>
<body>
  <h1>Log Summary</h1>

  <!-- Reset log button -->
  <form method="post" onsubmit="return confirm('Really clear all log data?');">
    <button class="reset-btn" type="submit" name="reset">🗑️ Reset Log</button>
  </form>

  <p><strong>Total entries:</strong> <?= $totalEntries ?></p>
  <p><strong>Current threshold:</strong> <?= $latestThreshold ?></p>
  <p><strong>Abnormal power events:</strong> <?= $abnormalPower ?></p>

  <h2>Events Table (Collision or Power Events)</h2>
  <table>
    <tr><th>Device Time</th><th>Power</th><th>Event</th></tr>
    <?= $eventRows ?: '<tr><td colspan="3">No events</td></tr>' ?>
  </table>

  <h2>Live Chart (refreshes every 5 s)</h2>
  <div id="chartContainer" style="height: 350px; width: 100%;"></div>
  <script>
    const rawData = <?= json_encode($chartData, JSON_NUMERIC_CHECK) ?>;
    function renderChart() {
      const dpsLight = [], dpsPower = [];
      rawData.forEach(pt => {
        const t = new Date(pt.deviceTime).getTime();
        dpsLight.push({ x: t, y: pt.light });
        dpsPower.push({ x: t, y: pt.power });
      });
      new CanvasJS.Chart("chartContainer", {
        title: { text: "Light & Power Levels Over Time" },
        axisX: { title: "Time", valueFormatString: "HH:mm:ss" },
        axisY: { title: "Sensor Value" },
        data: [
          { type: "line", showInLegend: true, legendText: "Light", dataPoints: dpsLight },
          { type: "line", showInLegend: true, legendText: "Power", dataPoints: dpsPower }
        ]
      }).render();
    }
    renderChart();
    setInterval(renderChart, 5000);
    // reload entire page every 5 s
    setInterval(function(){
        window.location.reload();
    }, 5000);    
  </script>
</body>
</html>
