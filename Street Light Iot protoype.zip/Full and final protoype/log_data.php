<?php
$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    http_response_code(400);
    exit("Invalid data");
}

$xmlFile = "log.xml";
if (!file_exists($xmlFile)) {
    file_put_contents($xmlFile, "<?xml version=\"1.0\"?><entries></entries>");
}

$xml = simplexml_load_file($xmlFile);

$entry = $xml->addChild("entry");
$entry->addChild("deviceTime", $data["timestamp"]);
$entry->addChild("serverTime", date("Y-m-d H:i:s"));
$entry->addChild("light", $data["light"]);
$entry->addChild("power", $data["power"]);
$entry->addChild("collision", $data["collision"]);
$entry->addChild("threshold", $data["threshold"]);

$xml->asXML($xmlFile);

echo "ACK";
?>
